/*
Load.hpp
*/

#ifndef LOAD_HPP
#define LOAD_HPP

class Mesh
{
public:

	//determine the position of factors
	GLuint vertex;
	GLuint texture;
	GLuint normal;
	GLuint index;

	// save all the things
	std::vector<glm::vec3> Vertexes;
	std::vector<glm::vec2> UVs;
	std::vector<glm::vec3> Normals;
	std::vector<unsigned short> Indices;

	//texture index
	GLuint Texture;

	//bind data to mesh
	void bindData();

	//draw mesh
	void draw(GLuint programID);
};

class ECE_OBJ_Loader
{
public:
	std::vector<Mesh> meshes;
	std::vector<int> textureIndices;


	//load obj and set mesh
	bool loadFile(const std::string& filename);

	//render data to mesh
	void renderMeshes(GLuint program);

};

// Load a .BMP file using our custom loader
GLuint loadBMP_custom(const char * imagepath);



#endif