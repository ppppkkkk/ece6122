/*

Load.cpp

*/


// Include standard headers
#include <string>
#include <fstream>
#include <vector>
#include <map>
#include <sstream>
#include <iostream>

// Include GLEW
#include <GL/glew.h>

// assimp
#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

// Include GLFW
#include <GLFW/glfw3.h>

// Include GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>



#include "Load.hpp"


void Mesh::bindData()
{
	//bind vertex
	glGenVertexArrays(1, &vertex);
	glBindVertexArray(vertex);
	glGenBuffers(1, &vertex);
	glBindBuffer(GL_ARRAY_BUFFER, vertex);
	glBufferData(GL_ARRAY_BUFFER, Vertexes.size() * sizeof(glm::vec3), &Vertexes[0], GL_STATIC_DRAW);
	//bind UV
	if (this->UVs.empty() == false)
	{
		glGenVertexArrays(1, &texture);
		glBindVertexArray(texture);
		glGenBuffers(1, &texture);
		glBindBuffer(GL_ARRAY_BUFFER, texture);
		glBufferData(GL_ARRAY_BUFFER, UVs.size() * sizeof(glm::vec2), &UVs[0], GL_STATIC_DRAW);
	}

	//bind normal
	glGenVertexArrays(1, &normal);
	glBindVertexArray(normal);
	glGenBuffers(1, &normal);
	glBindBuffer(GL_ARRAY_BUFFER, normal);
	glBufferData(GL_ARRAY_BUFFER, Normals.size() * sizeof(glm::vec3), &Normals[0], GL_STATIC_DRAW);

	//bind index
	if (this->Indices.empty() == false)
	{
		glGenVertexArrays(1, &index);
		glBindVertexArray(index);
		glGenBuffers(1, &index);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, Indices.size() * sizeof(unsigned short), &Indices[0], GL_STATIC_DRAW);
	}

}

void Mesh::draw(GLuint programID)
{
	//bind texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, Texture);

	GLuint TextureID = glGetUniformLocation(programID, "myTextureSampler");
	glUniform1i(TextureID, 0);

	// vertex
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vertex);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

	// UV
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, texture);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);

	// normal
	glEnableVertexAttribArray(2);
	glBindBuffer(GL_ARRAY_BUFFER, normal);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, 0);

	// Indices
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index);

	//draw
	glDrawElements(GL_TRIANGLES, this->Indices.size(), GL_UNSIGNED_SHORT, 0);

	glDisableVertexAttribArray(0);
	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(2);
}



bool ECE_OBJ_Loader::loadFile(const std::string& filename)
{
	//load model
	Assimp::Importer import;
	const aiScene* scene = import.ReadFile(filename, aiProcess_Triangulate | aiProcess_JoinIdenticalVertices | aiProcess_SortByPType);
	if (!scene)
	{
		std::cout << "Error: " << import.GetErrorString() << std::endl;
		exit(-1);
	}

	// set mesh
	for (int i = 0; i < scene->mNumMeshes; i++)
	{
		meshes.push_back(Mesh());
		Mesh& mesh = meshes.back();
		// get mesh
		aiMesh* aimesh = scene->mMeshes[i];

		// send to mesh
		for (int j = 0; j < aimesh->mNumVertices; j++)
		{
			//vertex
			mesh.Vertexes.push_back(glm::vec3(aimesh->mVertices[j].x, aimesh->mVertices[j].y, aimesh->mVertices[j].z));

			// normals
			mesh.Normals.push_back(glm::vec3(aimesh->mNormals[j].x, aimesh->mNormals[j].y, aimesh->mNormals[j].z));

			// uv
			if (aimesh->mTextureCoords[0])
			{
				mesh.UVs.push_back(glm::vec2(aimesh->mTextureCoords[0][j].x, aimesh->mTextureCoords[0][j].y));
			}
			else
			{
				mesh.UVs.push_back(glm::vec2(0, 0));
			}

		}


		//face
		for (GLuint j = 0; j < aimesh->mNumFaces; j++)
		{
			aiFace face = aimesh->mFaces[j];
			for (GLuint k = 0; k < face.mNumIndices; k++)
			{
				mesh.Indices.push_back(face.mIndices[k]);
			}
		}

		mesh.Texture = aimesh->mMaterialIndex;

	}



	//load texture
	for (int i = 0; i < scene->mNumMaterials; i++)
	{
		int textIndex = 0;
		aiString path;
		const aiMaterial* material = scene->mMaterials[i];

		if (material->GetTexture(aiTextureType_DIFFUSE, textIndex, &path) == AI_SUCCESS)
		{
			this->textureIndices.push_back(loadBMP_custom((std::string("C:\\Users\\11792\\Desktop\\obj_static\\") + path.data).c_str()));
		}
	}

	//bind data to mesh
	for (int i = 0; i < meshes.size(); i++)
	{
		meshes[i].bindData();
	}

	return true;
}



void ECE_OBJ_Loader::renderMeshes(GLuint programID)
{
	
	for (int i = 0; i < meshes.size(); i++)
	{
		meshes[i].draw(programID);
	}
}


GLuint loadBMP_custom(const char * imagepath){

	printf("Reading image %s\n", imagepath);

	// Data read from the header of the BMP file
	unsigned char header[54];
	unsigned int dataPos;
	unsigned int imageSize;
	unsigned int width, height;
	// Actual RGB data
	unsigned char * data;

	// Open the file
	FILE * file = fopen(imagepath,"rb");
	if (!file){
		printf("%s could not be opened. Are you in the right directory ? Don't forget to read the FAQ !\n", imagepath);
		getchar();
		return 0;
	}

	// Read the header, i.e. the 54 first bytes

	// If less than 54 bytes are read, problem
	if ( fread(header, 1, 54, file)!=54 ){ 
		printf("Not a correct BMP file\n");
		fclose(file);
		return 0;
	}
	// A BMP files always begins with "BM"
	if ( header[0]!='B' || header[1]!='M' ){
		printf("Not a correct BMP file\n");
		fclose(file);
		return 0;
	}
	// Make sure this is a 24bpp file
	if ( *(int*)&(header[0x1E])!=0  )         {printf("Not a correct BMP file\n");    fclose(file); return 0;}
	if ( *(int*)&(header[0x1C])!=24 )         {printf("Not a correct BMP file\n");    fclose(file); return 0;}

	// Read the information about the image
	dataPos    = *(int*)&(header[0x0A]);
	imageSize  = *(int*)&(header[0x22]);
	width      = *(int*)&(header[0x12]);
	height     = *(int*)&(header[0x16]);

	// Some BMP files are misformatted, guess missing information
	if (imageSize==0)    imageSize=width*height*3; // 3 : one byte for each Red, Green and Blue component
	if (dataPos==0)      dataPos=54; // The BMP header is done that way

	// Create a buffer
	data = new unsigned char [imageSize];

	// Read the actual data from the file into the buffer
	fread(data,1,imageSize,file);

	// Everything is in memory now, the file can be closed.
	fclose (file);

	// Create one OpenGL texture
	GLuint textureID;
	glGenTextures(1, &textureID);
	
	// "Bind" the newly created texture : all future texture functions will modify this texture
	glBindTexture(GL_TEXTURE_2D, textureID);

	// Give the image to OpenGL
	glTexImage2D(GL_TEXTURE_2D, 0,GL_RGB, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, data);

	// OpenGL has now copied the data. Free our own version
	delete [] data;

	// Poor filtering, or ...
	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); 

	// ... nice trilinear filtering ...
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	// ... which requires mipmaps. Generate them automatically.
	glGenerateMipmap(GL_TEXTURE_2D);

	// Return the ID of the texture we just created
	return textureID;
}



