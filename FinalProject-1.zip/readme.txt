1. The two videos show the control and the model loading.
2. I turn these picture into .png so I can use the tutorial's function 