//write the function of the ghost class
#include "ghosts.h"

//constructor of the ghost
Ghosts::Ghosts(string name, float x, float y)
{
	//load
	textureOfGhost.loadFromFile("B:\\pacmango\\pacmango\\graphics\\" + name + "_ghost" + ".bmp");
	spriteGhost.setTexture(textureOfGhost);
	//set position and speed

	spriteGhost.setPosition(x, y);
	//first time movement
	switch (rand() % 4)
	{
	case 0:
		ghostMoveDirX = 1;
		ghostMoveDirY = 0;
		break;
	case 1:
		ghostMoveDirX = -1;
		ghostMoveDirY = 0;
		break;
	case 2:
		ghostMoveDirX = 0;
		ghostMoveDirY = -1;
		break;
	case 3:
		ghostMoveDirX = 0;
		ghostMoveDirY = 1;
		break;
	}
}
//set position
void Ghosts::setPosition(float x, float y)
{
	spriteGhost.setPosition(x, y);
}

//get boundry
FloatRect Ghosts::getGhostBound()
{
	return spriteGhost.getGlobalBounds();
}
//when collision
void Ghosts::ghostCollision()
{
	//choose anothor direction
	switch (rand() % 4)
	{
	case 0:
		ghostMoveDirX = 1;
		ghostMoveDirY = 0;
		break;
	case 1:
		ghostMoveDirX = -1;
		ghostMoveDirY = 0;
		break;
	case 2:
		ghostMoveDirX = 0;
		ghostMoveDirY = -1;
		break;
	case 3:
		ghostMoveDirX = 0;
		ghostMoveDirY = 1;
		break;
	}

}

//update the position
void Ghosts::updatePosition()
{
	spriteGhost.setPosition(spriteGhost.getPosition().x + ghostMoveDirX * ghostSpeed, spriteGhost.getPosition().y + ghostMoveDirY * ghostSpeed);
}
