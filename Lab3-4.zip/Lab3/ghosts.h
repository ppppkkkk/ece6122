/*
class ghosts 
*/
#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>

using namespace sf;
using namespace std;

class Ghosts
{
public:
	Sprite spriteGhost;
	Texture textureOfGhost;


	float ghostMoveDirX = 0;
	float ghostMoveDirY = 0;
	float ghostSpeed = 0;
	//constructor
	Ghosts(string name, float x, float y);
	//set position of ghost
	void setPosition(float x, float y);
	//get the ghost's boundry
	FloatRect getGhostBound();
	//if collision
	void ghostCollision();
	//update the position
	void updatePosition();

};