/*
class Pacman to build pacman object
*/

#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
using namespace sf;
using namespace std;

class Pacman
{
public:

	Sprite pacmanSprite;
	Texture textureOfPacman;

	float pacmanPositionX;
	float pacmanPositionY;
	float pacmanSpeed = 0;

	//constructor
	Pacman(string name, float x, float y);
	//test constructor
	Pacman(string name);
	//set position
	void setPosition(float x, float y);
	//get boundry
	FloatRect getPacmanBound();


};