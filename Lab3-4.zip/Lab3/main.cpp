﻿/*
Author: PEI XIANGJUN
Class : ECE6122
Last Date Modified : 2022.10.24

Write a C++ application that uses SFML to create a simple pacman game.
Game Rules:
• (~5 pts) Display the provided pac-man.bmp at the start of the game with the extra text
o PRESS ENTER TO START
 in the middle of the window.
• (~20 pts) Once the user presses the ENTER key the game starts with
o pacman located as shown above
o all four ghosts start at the same location as shown above (bitmaps provided)
o place the four power ups as shown above
o place the coins as shown above
• (~10 pts) The ghost’s initial direction is determined randomly and when a ghost hits a wall
its new direction is chosen randomly.
• (~20 pts) Control the location of pacman using the left, right, up, down arrow keys. • (~10 pts) Determine a game speed that makes the game fun to play (not too slow and not to
fast)
• (~10 pts) The game ends when
o one of the ghosts comes in contact with a non-powered up pacman
o pacman consumes all the coins
o user presses the escape key.
• (~5 pts) When pacman eats a powerup he can eat ghosts for 5 seconds. Ghosts that are
eaten are gone forever.
• (~15 pts) Pacman and the ghost cannot go through walls.
• (~5 pts) Pacman and the ghost can go through the middle tunnels on each side.
• You do not have to handle resizing the window. Just use the image size.

include 5 files
main.cpp
ghosts.cpp
pacman.cpp
pacman.h
ghosts.h

*/


#include "ghosts.h"
#include "pacman.h"

constexpr float CELL = 20.5f;//the distance between 2 coins;
constexpr float STARTX = 42.f;//the start x position 0-26*CELL
constexpr float STARTY = 35.f;//the start y position 0-29*CELL
constexpr float COINSTARTX = 60.f;//the start x position of coin
constexpr float COINSTARTY = 55.f;//the start y position of coin

//pace man collision test
int indexBarriersLeft = 0;
int indexBarriersRight = 0;
int indexBarriersUp = 0;
int indexBarriersDown = 0;

bool pacCollisionLeft = false;
bool pacCollisionRight = false;
bool pacCollisionUp = false;
bool pacCollisionDown = false;

// Are the objects currently moving?
bool pacemanActive = false;
bool ghostsActive = false;

// Control the player input
bool acceptInput = false;


//Create a pacman and ghosts
Pacman pacmanSprite("pacman",3000,3000);
Ghosts blueGhostSprite("blue", 2000, 2000);
Ghosts orangeGhostSprite("orange", 2000, 2000);
Ghosts pinkGhostSprite("pink", 2000, 2000);
Ghosts redGhostSprite("red", 2000, 2000);
//left num of ghost
int ghostNum = 4;
//Create pacman's test
Pacman upTest("pacman");
Pacman downTest("pacman");
Pacman leftTest("pacman");
Pacman rightTest("pacman");


// control of ghost movement

int main()
{

	//Create the game window
	RenderWindow window(sf::VideoMode(641, 728), "PacMan");
	
	// Create a texture to the start
	Texture textureBackground;
	textureBackground.loadFromFile("B:\\pacmango\\pacmango\\graphics\\pac-man.bmp");
	Sprite spriteBackground;
	spriteBackground.setTexture(textureBackground);
	spriteBackground.setPosition(0, 0);

	// Create a texture to the game background
	Texture textureGameBackground;
	textureGameBackground.loadFromFile("B:\\pacmango\\pacmango\\graphics\\maze.bmp");
	Sprite spriteGameBackground;
	spriteGameBackground.setTexture(textureGameBackground);
	spriteGameBackground.setPosition(2000, 2000);
	
	//Enter text
	Text messageText;
	sf::Font font;
	font.loadFromFile("B:\\pacmango\\pacmango\\fonts\\KOMIKAP_.ttf");
	messageText.setFont(font);
	messageText.setString("Press Enter to start!");
	messageText.setCharacterSize(37);
	messageText.setFillColor(Color::White);

	FloatRect textRect = messageText.getLocalBounds();
	messageText.setOrigin(textRect.left +
		textRect.width / 2.0f,
		textRect.top +
		textRect.height / 2.0f);

	messageText.setPosition(641 / 2.0f, 728 / 2.0f);
	
	//Win text
	Text winText;
	winText.setFont(font);
	winText.setString("Win!");
	winText.setCharacterSize(37);
	winText.setFillColor(Color::White);

	FloatRect textWinRect = winText.getLocalBounds();
	winText.setOrigin(textWinRect.left +
		textWinRect.width / 2.0f,
		textWinRect.top +
		textWinRect.height / 2.0f);

	winText.setPosition(2000, 2000);

	//Lose text
	Text loseText;
	loseText.setFont(font);
	loseText.setString("Lose!");
	loseText.setCharacterSize(37);
	loseText.setFillColor(Color::White);

	FloatRect textLoseRect = loseText.getLocalBounds();
	loseText.setOrigin(textLoseRect.left +
		textLoseRect.width / 2.0f,
		textLoseRect.top +
		textLoseRect.height / 2.0f);

	loseText.setPosition(2000, 2000);


	//Create coins
	vector<CircleShape> coins;
	CircleShape c;
	c.setRadius(2.1f);
	c.setFillColor(Color::White);

	for (int i = 0;i < 29;++i)
	{
		if (i != 26 && i != 27)
		{
			c.setPosition(COINSTARTX + 5 * CELL, COINSTARTY + i * CELL);
			coins.push_back(c);
			c.setPosition(COINSTARTX + 20 * CELL, COINSTARTY + i * CELL);
			coins.push_back(c);
		}
	}

	for (int i = 0;i < 26;++i)
	{
		c.setPosition(COINSTARTX + i * CELL, COINSTARTY + 4 * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + i * CELL, COINSTARTY + 28 * CELL);
		coins.push_back(c);

		if (i != 12 && i != 13)
		{
			c.setPosition(COINSTARTX + i * CELL, COINSTARTY);
			coins.push_back(c);
			c.setPosition(COINSTARTX + i * CELL, COINSTARTY + 19 * CELL);
			coins.push_back(c);
		}

		if (i != 12 && i != 13 && i != 3 && i != 4 && i != 21 && i != 22)
		{
			c.setPosition(COINSTARTX + i * CELL, COINSTARTY + 22 * CELL);
			coins.push_back(c);
		}

		if (i != 12 && i != 13 && i != 6 && i != 7 && i != 18 && i != 19)
		{
			c.setPosition(COINSTARTX + i * CELL, COINSTARTY + 7 * CELL);
			coins.push_back(c);
			c.setPosition(COINSTARTX + i * CELL, COINSTARTY + 25 * CELL);
			coins.push_back(c);
		}

	}

	for (int i = 0;i < 2;++i)
	{
		c.setPosition(COINSTARTX, COINSTARTY + (i + 1) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX, COINSTARTY + (i + 5) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX, COINSTARTY + (i + 20) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX, COINSTARTY + (i + 26) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 11 * CELL, COINSTARTY + (i + 1) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 11 * CELL, COINSTARTY + (i + 20) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 11 * CELL, COINSTARTY + (i + 26) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 14 * CELL, COINSTARTY + (i + 1) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 14 * CELL, COINSTARTY + (i + 20) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 14 * CELL, COINSTARTY + (i + 26) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 25 * CELL, COINSTARTY + (i + 1) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 25 * CELL, COINSTARTY + (i + 20) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 25 * CELL, COINSTARTY + (i + 26) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 2 * CELL, COINSTARTY + (i + 23) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 8 * CELL, COINSTARTY + (i + 23) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 8 * CELL, COINSTARTY + (i + 5) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 17 * CELL, COINSTARTY + (i + 23) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 17 * CELL, COINSTARTY + (i + 5) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 23 * CELL, COINSTARTY + (i + 23) * CELL);
		coins.push_back(c);
		c.setPosition(COINSTARTX + 25 * CELL, COINSTARTY + (i + 5) * CELL);
		coins.push_back(c);
	}

	c.setPosition(COINSTARTX, COINSTARTY + 3 * CELL);
	coins.push_back(c);
	c.setPosition(COINSTARTX + 11 * CELL, COINSTARTY + 3 * CELL);
	coins.push_back(c);
	c.setPosition(COINSTARTX + 14 * CELL, COINSTARTY + 3 * CELL);
	coins.push_back(c);
	c.setPosition(COINSTARTX + 25 * CELL, COINSTARTY + 3 * CELL);
	coins.push_back(c);


	//use to measure the sum of coins 
	vector<CircleShape> coinsControl;
	for (int i = 0;i < coins.size();++i)
	{
		coinsControl.push_back(coins[i]);
	}

	int coinBeenEaten = 0;


	//Create  power ups
	vector<CircleShape> power;

	CircleShape p;
	p.setRadius(5.7f);
	p.setFillColor(Color::White);
	p.setPosition(56.5f, 52.5f + 2 * CELL);
	power.push_back(p);
	p.setPosition(56.5f + 25 * CELL, 52.5f + 2 * CELL);
	power.push_back(p);
	p.setPosition(56.5f, 52.5f + 22 * CELL);
	power.push_back(p);
	p.setPosition(56.5f + 25 * CELL, 52.5f + 22 * CELL);
	power.push_back(p);

	//draw all barriers;
	vector<RectangleShape> barriers;

	//draw walls
	vector<RectangleShape> walls;
	RectangleShape w1(Vector2f(555.f, 1.f));
	w1.setPosition(STARTX, STARTY);
	walls.push_back(w1);
	w1.setPosition(STARTX, 36.f + 30 * CELL);
	walls.push_back(w1);

	RectangleShape w2(Vector2f(186.f, 1.f));
	w2.setPosition(STARTX, STARTY);
	w2.rotate(90.f);
	walls.push_back(w2);
	w2.setPosition(STARTX + 555.f, STARTY);
	walls.push_back(w2);

	RectangleShape w3(Vector2f(101.f, 1.f));
	w3.setPosition(STARTX - 0.5f, STARTY + 186.f);
	walls.push_back(w3);
	w3.setPosition(STARTX + 453.f, STARTY + 186.f);
	walls.push_back(w3);
	w3.setPosition(STARTX + 453.f, STARTY + 387.f);
	walls.push_back(w3);
	w3.setPosition(STARTX - 0.5f, STARTY + 387.f);
	walls.push_back(w3);

	RectangleShape w4(Vector2f(300.f, 1.f));
	w4.setPosition(-158.f, STARTY + 265.f);
	walls.push_back(w4);
	w4.setPosition(-158.f, STARTY + 310.f);
	walls.push_back(w4);
	w4.setPosition(494.f, STARTY + 310.f);
	walls.push_back(w4);
	w4.setPosition(494.f, STARTY + 265.f);
	walls.push_back(w4);

	RectangleShape w5(Vector2f(229.f, 1.f));
	w5.setPosition(STARTX, STARTY + 387.f);
	w5.rotate(90.f);
	walls.push_back(w5);
	w5.setPosition(STARTX + 555.f, STARTY + 387.f);
	walls.push_back(w5);


	RectangleShape w6(Vector2f(77.5f, 1.f));
	w6.setPosition(STARTX + 100.5f, STARTY + 186.5f );
	w6.rotate(90.f);
	walls.push_back(w6);
	w6.setPosition(STARTX + 453.f, STARTY + 186.5f);
	walls.push_back(w6);
	w6.setPosition(STARTX + 100.5f, STARTY + 310.f);
	walls.push_back(w6);
	w6.setPosition(STARTX + 453.f, STARTY + 310.f);
	walls.push_back(w6);

	RectangleShape w7(Vector2f(4 * CELL, 1.f));
	w7.setPosition(STARTX + 10 * CELL, 14 * CELL - 3.5f);
	w7.rotate(90.f);
	walls.push_back(w7);
	w7.setPosition(STARTX + 17 * CELL, 14 * CELL - 3.5f);
	walls.push_back(w7);

	RectangleShape w8(Vector2f(7 * CELL, 1.f));
	w8.setPosition(STARTX + 10 * CELL, 14 * CELL - 3.3f);
	walls.push_back(w8);
	w8.setPosition(STARTX + 10 * CELL, 18 * CELL - 3.5f);
	walls.push_back(w8);







	for (int i = 0;i < walls.size();++i)
	{
		barriers.push_back(walls[i]);
		walls[i].setFillColor(Color::Transparent);
	}

	//draw obstacles
	vector<RectangleShape> obstacles;

	RectangleShape o1(Vector2f(1 * CELL, 3 * CELL));
	o1.setPosition(STARTX + 4 * CELL, STARTY + 22 * CELL);
	obstacles.push_back(o1);
	o1.setPosition(STARTX + 22 * CELL, STARTY + 22 * CELL);
	obstacles.push_back(o1);
	o1.setPosition(STARTX + 7 * CELL, STARTY + 24 * CELL);
	obstacles.push_back(o1);
	o1.setPosition(STARTX + 19 * CELL, STARTY + 24 * CELL);
	obstacles.push_back(o1);

	RectangleShape o2(Vector2f(1 * CELL, 4 * CELL));
	o2.setPosition(STARTX + 13 * CELL, STARTY + 0 * CELL);
	obstacles.push_back(o2);
	o2.setPosition(STARTX + 13 * CELL, STARTY + 6 * CELL);
	obstacles.push_back(o2);
	o2.setPosition(STARTX + 13 * CELL, STARTY + 18 * CELL);
	obstacles.push_back(o2);
	o2.setPosition(STARTX + 13 * CELL, STARTY + 24 * CELL);
	obstacles.push_back(o2);
	o2.setPosition(STARTX + 7 * CELL, STARTY + 15 * CELL);
	obstacles.push_back(o2);
	o2.setPosition(STARTX + 19 * CELL, STARTY + 15 * CELL);
	obstacles.push_back(o2);

	RectangleShape o3(Vector2f(1 * CELL, 7 * CELL));
	o3.setPosition(STARTX + 7 * CELL, STARTY + 6 * CELL);
	obstacles.push_back(o3);
	o3.setPosition(STARTX + 19 * CELL, STARTY + 6 * CELL);
	obstacles.push_back(o3);

	RectangleShape o4(Vector2f(2 * CELL, 1 * CELL));
	o4.setPosition(STARTX + 0 * CELL, STARTY + 24 * CELL);
	obstacles.push_back(o4);
	o4.setPosition(STARTX + 25 * CELL, STARTY + 24 * CELL);
	obstacles.push_back(o4);

	RectangleShape o5(Vector2f(3 * CELL, 1 * CELL));
	o5.setPosition(STARTX + 2 * CELL, STARTY + 6 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 10 * CELL, STARTY + 6 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 14 * CELL, STARTY + 6 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 10 * CELL, STARTY + 24 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 14 * CELL, STARTY + 24 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 10 * CELL, STARTY + 18 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 14 * CELL, STARTY + 18 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 22 * CELL, STARTY + 6 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 8 * CELL, STARTY + 9 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 16 * CELL, STARTY + 9 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 2 * CELL, STARTY + 21 * CELL);
	obstacles.push_back(o5);
	o5.setPosition(STARTX + 22 * CELL, STARTY + 21 * CELL);
	obstacles.push_back(o5);

	RectangleShape o6(Vector2f(3 * CELL, 2 * CELL));
	o6.setPosition(STARTX + 2 * CELL, STARTY + 2 * CELL);
	obstacles.push_back(o6);
	o6.setPosition(STARTX + 22 * CELL, STARTY + 2 * CELL);
	obstacles.push_back(o6);

	RectangleShape o7(Vector2f(4 * CELL, 1 * CELL));
	o7.setPosition(STARTX + 7 * CELL, STARTY + 21 * CELL);
	obstacles.push_back(o7);
	o7.setPosition(STARTX + 16 * CELL, STARTY + 21 * CELL);
	obstacles.push_back(o7);

	RectangleShape o8(Vector2f(4 * CELL, 2 * CELL));
	o8.setPosition(STARTX + 7 * CELL, STARTY + 2 * CELL);
	obstacles.push_back(o8);
	o8.setPosition(STARTX + 16 * CELL, STARTY + 2 * CELL);
	obstacles.push_back(o8);


	RectangleShape o9(Vector2f(9 * CELL, 1 * CELL));
	o9.setPosition(STARTX + 2 * CELL, STARTY + 27 * CELL);
	obstacles.push_back(o9);
	o9.setPosition(STARTX + 16 * CELL, STARTY + 27 * CELL);
	obstacles.push_back(o9);




	for (int i = 0;i < obstacles.size();++i)
	{
		barriers.push_back(obstacles[i]);
		obstacles[i].setFillColor(Color::Transparent);
	}

	//control power time
	clock_t startTime;
	clock_t endTime;
	bool timeFlag = false;

	while (window.isOpen())
	{
		Event evt;
		while (window.pollEvent(evt))
		{
			if(evt.type == Event::KeyReleased)
			{
				// Listen for key presses again
				acceptInput = true;
			}
			if(evt.type == Event::Closed)
			{
				window.close();
			}
		}

		//close the game
		if (Keyboard::isKeyPressed(Keyboard::Escape))
		{
			window.close();
		}

		//enter the game
		if (Keyboard::isKeyPressed(Keyboard::Return))
		{
			window.clear();
			coinBeenEaten = 0;
			acceptInput = true;
			ghostsActive = true;
			coins.clear();
			for (int i = 0;i < coinsControl.size();++i)
			{
				coins.push_back(coinsControl[i]);
			}
			power.clear();
			p.setPosition(56.5f, 2 * CELL + 52.5f);
			power.push_back(p);
			p.setPosition(56.5f, 22 * CELL + 52.5f);
			power.push_back(p);
			p.setPosition(56.5f + 25 * CELL, 2 * CELL + 52.5f);
			power.push_back(p);
			p.setPosition(56.5f + 25 * CELL, 22 * CELL + 52.5f);
			power.push_back(p);
			messageText.setPosition(2000, 2000);
			winText.setPosition(2000, 2000);
			loseText.setPosition(2000, 2000);
			spriteBackground.setPosition(2000, 2000);
			spriteGameBackground.setPosition(0, 0);
			pacmanSprite.setPosition(304, 492);
			redGhostSprite.setPosition(304, 248);
			blueGhostSprite.setPosition(304, 248);
			orangeGhostSprite.setPosition(304, 248);
			pinkGhostSprite.setPosition(304, 248);
			redGhostSprite.ghostSpeed = 0.12f;
			blueGhostSprite.ghostSpeed = 0.12f;
			orangeGhostSprite.ghostSpeed = 0.12f;
			pinkGhostSprite.ghostSpeed = 0.12f;
			ghostNum = 4;


		}

		//when pacman faces the ghosts and pacman is full of power
		if (redGhostSprite.ghostSpeed == 0.01f && pacmanSprite.getPacmanBound().intersects(redGhostSprite.getGhostBound()))
		{
			redGhostSprite.setPosition(2000, 2000);
			redGhostSprite.ghostSpeed = 0;
			--ghostNum;
		}

		if (orangeGhostSprite.ghostSpeed == 0.01f && pacmanSprite.getPacmanBound().intersects(orangeGhostSprite.getGhostBound()))
		{
			orangeGhostSprite.setPosition(2000, 2000);
			redGhostSprite.ghostSpeed = 0;
			--ghostNum;
		}

		if (blueGhostSprite.ghostSpeed == 0.01f && pacmanSprite.getPacmanBound().intersects(blueGhostSprite.getGhostBound()))
		{
			blueGhostSprite.setPosition(2000, 2000);
			blueGhostSprite.ghostSpeed = 0;
			--ghostNum;
		}

		if (pinkGhostSprite.ghostSpeed == 0.01f && pacmanSprite.getPacmanBound().intersects(pinkGhostSprite.getGhostBound()))
		{
			pinkGhostSprite.setPosition(2000, 2000);
			pinkGhostSprite.ghostSpeed = 0;
			--ghostNum;
		}

		//when pacman faces the ghosts and pacman is not full of power
		if (redGhostSprite.ghostSpeed == 0.12f && pacmanSprite.getPacmanBound().intersects(redGhostSprite.getGhostBound()) && acceptInput)
		{
			loseText.setPosition(641 / 2.0f, 728 / 2.0f);
			ghostsActive = false;
			acceptInput = false;
		}

		if (orangeGhostSprite.ghostSpeed == 0.12f && pacmanSprite.getPacmanBound().intersects(orangeGhostSprite.getGhostBound()) && acceptInput)
		{
			loseText.setPosition(641 / 2.0f, 728 / 2.0f);
			ghostsActive = false;
			acceptInput = false;
		}

		if (blueGhostSprite.ghostSpeed == 0.12f && pacmanSprite.getPacmanBound().intersects(blueGhostSprite.getGhostBound()) && acceptInput)
		{
			loseText.setPosition(641 / 2.0f, 728 / 2.0f);
			ghostsActive = false;
			acceptInput = false;
		}

		if (pinkGhostSprite.ghostSpeed == 0.12f && pacmanSprite.getPacmanBound().intersects(pinkGhostSprite.getGhostBound()) && acceptInput)
		{
			loseText.setPosition(641 / 2.0f, 728 / 2.0f);
			ghostsActive = false;
			acceptInput = false;
		}


		//win
		if (coinBeenEaten == coins.size()|| ghostNum == 0)
		{
			winText.setPosition(641 / 2.0f, 728 / 2.0f);
			ghostsActive = false;
			acceptInput = false;
		}

		//ghosts' movement
		if (ghostsActive)
		{
			redGhostSprite.updatePosition();
			pinkGhostSprite.updatePosition();
			orangeGhostSprite.updatePosition();
			blueGhostSprite.updatePosition();

			//collision?
			for (int i = 0; i < barriers.size(); ++i)
			{
				FloatRect barrierBound = barriers[i].getGlobalBounds();
				//red collision?
				if (redGhostSprite.getGhostBound().intersects(barrierBound))
				{
					Ghosts ghostTestRed = redGhostSprite;
					while(1)
					{
						ghostTestRed.setPosition(ghostTestRed.spriteGhost.getPosition().x - ghostTestRed.ghostMoveDirX * ghostTestRed.ghostSpeed, ghostTestRed.spriteGhost.getPosition().y - ghostTestRed.ghostMoveDirY * ghostTestRed.ghostSpeed);//back
						ghostTestRed.ghostCollision();//back collide?
						ghostTestRed.updatePosition();
						//new position not collide
						if (!ghostTestRed.getGhostBound().intersects(barrierBound))
						{
							break;
						}
					}
					redGhostSprite = ghostTestRed;
				}
				//pink collision?
				if (pinkGhostSprite.getGhostBound().intersects(barrierBound))
				{
					Ghosts ghostTestPink = pinkGhostSprite;
					while (1)
					{
						ghostTestPink.setPosition(ghostTestPink.spriteGhost.getPosition().x - ghostTestPink.ghostMoveDirX * ghostTestPink.ghostSpeed, ghostTestPink.spriteGhost.getPosition().y - ghostTestPink.ghostMoveDirY * ghostTestPink.ghostSpeed);//back
						ghostTestPink.ghostCollision();//back collide?
						ghostTestPink.updatePosition();
						//new position not collide
						if (!ghostTestPink.getGhostBound().intersects(barrierBound))
						{
							break;
						}
					}
					pinkGhostSprite = ghostTestPink;
				}
				//blue collision?
				if (blueGhostSprite.getGhostBound().intersects(barrierBound))
				{
					Ghosts ghostTestBlue = blueGhostSprite;
					while (1)
					{
						ghostTestBlue.setPosition(ghostTestBlue.spriteGhost.getPosition().x - ghostTestBlue.ghostMoveDirX * ghostTestBlue.ghostSpeed, ghostTestBlue.spriteGhost.getPosition().y - ghostTestBlue.ghostMoveDirY * ghostTestBlue.ghostSpeed);//back//back
						ghostTestBlue.ghostCollision();//back collide?
						ghostTestBlue.updatePosition();
						//new position not collide
						if (!ghostTestBlue.getGhostBound().intersects(barrierBound))
						{
							break;
						}
					}
					blueGhostSprite = ghostTestBlue;
				}
				//orange collision?
				if (orangeGhostSprite.getGhostBound().intersects(barrierBound))
				{
					Ghosts ghostTestOrange = orangeGhostSprite;
					while (1)
					{
						ghostTestOrange.setPosition(ghostTestOrange.spriteGhost.getPosition().x - ghostTestOrange.ghostMoveDirX * ghostTestOrange.ghostSpeed, ghostTestOrange.spriteGhost.getPosition().y - ghostTestOrange.ghostMoveDirY * ghostTestOrange.ghostSpeed);//back
						ghostTestOrange.ghostCollision();//back collide?
						ghostTestOrange.updatePosition();
						//new position not collide
						if (!ghostTestOrange.getGhostBound().intersects(barrierBound))
						{
							break;
						}
					}
					orangeGhostSprite = ghostTestOrange;
				}


			}
		}

		//control the coins that have been eaten
		for (int i = 0;i < coins.size();++i)
		{
			FloatRect coinsBound = coins[i].getGlobalBounds();
			if (coinsBound.intersects(pacmanSprite.getPacmanBound()))
			{
				coins[i].setFillColor(Color::Transparent);
				coins[i].setPosition(3000, 3000);
				coinBeenEaten++;
			}
		}
		
		//when eat a power up, slow down the ghost speed
		for (int i = 0;i < power.size();++i)
		{
			FloatRect powerBound = power[i].getGlobalBounds();
			if (powerBound.intersects(pacmanSprite.getPacmanBound()))
			{
				power[i].setFillColor(Color::Transparent);
				power[i].setPosition(2000, 2000);
				if (redGhostSprite.ghostSpeed)
				{
					redGhostSprite.ghostSpeed = 0.01f;
				}
				if (orangeGhostSprite.ghostSpeed)
				{
					orangeGhostSprite.ghostSpeed = 0.01f;
				}
				if (blueGhostSprite.ghostSpeed)
				{
					blueGhostSprite.ghostSpeed = 0.01f;
				}
				if (pinkGhostSprite.ghostSpeed)
				{
					pinkGhostSprite.ghostSpeed = 0.01f;
				}
				startTime = clock();
				timeFlag = true;
			}
		}

		//recover the speed of ghost
		if (timeFlag)
		{
			endTime = clock();
			float dur = (float)(endTime - startTime) / CLOCKS_PER_SEC;
			if (dur > 5)
			{
				if (redGhostSprite.ghostSpeed)
				{
					redGhostSprite.ghostSpeed = 0.12f;
				}
				if (orangeGhostSprite.ghostSpeed)
				{
					orangeGhostSprite.ghostSpeed = 0.12f;
				}
				if (blueGhostSprite.ghostSpeed)
				{
					blueGhostSprite.ghostSpeed = 0.12f;
				}
				if (pinkGhostSprite.ghostSpeed)
				{
					pinkGhostSprite.ghostSpeed = 0.12f;
				}
				timeFlag = false;
			}
			
		}


		
		if (acceptInput)
		{
			//go through the tunnel
			if (pacmanSprite.pacmanPositionX <-10)
			{
				pacmanSprite.setPosition(641, pacmanSprite.pacmanPositionY);
			}			
			if (pacmanSprite.pacmanPositionX > 641+10)
			{
				pacmanSprite.setPosition(0, pacmanSprite.pacmanPositionY);
			}
			if (redGhostSprite.spriteGhost.getPosition().x < -10)
			{
				redGhostSprite.setPosition(641, redGhostSprite.spriteGhost.getPosition().y);
			}
			if (redGhostSprite.spriteGhost.getPosition().x > 641 + 10)
			{
				redGhostSprite.setPosition(0, redGhostSprite.spriteGhost.getPosition().y);
			}
			if (blueGhostSprite.spriteGhost.getPosition().x < -10)
			{
				blueGhostSprite.setPosition(641, blueGhostSprite.spriteGhost.getPosition().y);
			}
			if (blueGhostSprite.spriteGhost.getPosition().x > 641 + 10)
			{
				blueGhostSprite.setPosition(0, blueGhostSprite.spriteGhost.getPosition().y);
			}
			if (pinkGhostSprite.spriteGhost.getPosition().x < -10)
			{
				pinkGhostSprite.setPosition(641, pinkGhostSprite.spriteGhost.getPosition().y);
			}
			if (pinkGhostSprite.spriteGhost.getPosition().x > 641 + 10)
			{
				pinkGhostSprite.setPosition(0, pinkGhostSprite.spriteGhost.getPosition().y);
			}
			if (orangeGhostSprite.spriteGhost.getPosition().x < -10)
			{
				orangeGhostSprite.setPosition(641, orangeGhostSprite.spriteGhost.getPosition().y);
			}
			if (orangeGhostSprite.spriteGhost.getPosition().x > 641 + 10)
			{
				orangeGhostSprite.setPosition(0, orangeGhostSprite.spriteGhost.getPosition().y);
			}

			//test the collision of pacman
			upTest.setPosition(pacmanSprite.pacmanPositionX, pacmanSprite.pacmanPositionY - 5);
			downTest.setPosition(pacmanSprite.pacmanPositionX, pacmanSprite.pacmanPositionY + 5);
			leftTest.setPosition(pacmanSprite.pacmanPositionX - 5, pacmanSprite.pacmanPositionY);
			rightTest.setPosition(pacmanSprite.pacmanPositionX + 5, pacmanSprite.pacmanPositionY);

			//barrier's collsion test
			FloatRect barriersBound;
			for (int i = 0;i < barriers.size();++i)
			{
				barriersBound = barriers[i].getGlobalBounds();
				if (leftTest.getPacmanBound().intersects(barriersBound))
				{
					pacCollisionLeft = true;
					indexBarriersLeft = i;	
				}

				if (rightTest.getPacmanBound().intersects(barriersBound))
				{
					pacCollisionRight = true;
					indexBarriersRight = i;
				}

				if (upTest.getPacmanBound().intersects(barriersBound))
				{
					pacCollisionUp = true;
					indexBarriersUp = i;
				}

				if (downTest.getPacmanBound().intersects(barriersBound))
				{
					pacCollisionDown = true;
					indexBarriersDown = i;
					
				}

			}

			
			//control the pacman's direction
			if (Keyboard::isKeyPressed(Keyboard::Right))
			{
				if (pacCollisionRight)
				{
					pacmanSprite.setPosition(pacmanSprite.pacmanPositionX, pacmanSprite.pacmanPositionY);
				}
				else
				{
					pacmanSprite.setPosition(pacmanSprite.pacmanPositionX + pacmanSprite.pacmanSpeed, pacmanSprite.pacmanPositionY);
				}

			}
			if (Keyboard::isKeyPressed(Keyboard::Left))
			{
				if (pacCollisionLeft)
				{
					pacmanSprite.setPosition(pacmanSprite.pacmanPositionX, pacmanSprite.pacmanPositionY);
				}
				else
				{
					pacmanSprite.setPosition(pacmanSprite.pacmanPositionX - pacmanSprite.pacmanSpeed, pacmanSprite.pacmanPositionY);
				}
				
			}
			if (Keyboard::isKeyPressed(Keyboard::Up))
			{
				if (pacCollisionUp)
				{
					pacmanSprite.setPosition(pacmanSprite.pacmanPositionX, pacmanSprite.pacmanPositionY);
				}
				else
				{
					pacmanSprite.setPosition(pacmanSprite.pacmanPositionX, pacmanSprite.pacmanPositionY - pacmanSprite.pacmanSpeed);
				}
				
			}
			if (Keyboard::isKeyPressed(Keyboard::Down))
			{
				if (pacCollisionDown)
				{
					pacmanSprite.setPosition(pacmanSprite.pacmanPositionX, pacmanSprite.pacmanPositionY);
				}
				else
				{
					pacmanSprite.setPosition(pacmanSprite.pacmanPositionX, pacmanSprite.pacmanPositionY + pacmanSprite.pacmanSpeed);
				}
				
			}

			//recover the collision's status
			if (indexBarriersLeft != -1)
			{
				barriersBound = barriers[indexBarriersLeft].getGlobalBounds();
				if (!leftTest.getPacmanBound().intersects(barriersBound))
				{
					pacCollisionLeft = false;
				}
			}

			if (indexBarriersRight != -1)
			{
				barriersBound = barriers[indexBarriersRight].getGlobalBounds();
				if (!rightTest.getPacmanBound().intersects(barriersBound))
				{
					pacCollisionRight = false;
				}
			}

			if (indexBarriersUp != -1)
			{
				barriersBound = barriers[indexBarriersUp].getGlobalBounds();
				if (!upTest.getPacmanBound().intersects(barriersBound))
				{
					pacCollisionUp = false;
				}
			}

			if (indexBarriersDown != -1)
			{
				barriersBound = barriers[indexBarriersDown].getGlobalBounds();
				if (!downTest.getPacmanBound().intersects(barriersBound))
				{
					pacCollisionDown = false;
				}
			}
		}

		window.clear();
		//draw some pictures
		window.draw(spriteGameBackground);
		window.draw(spriteBackground);
		window.draw(pacmanSprite.pacmanSprite);
		window.draw(blueGhostSprite.spriteGhost);
		window.draw(orangeGhostSprite.spriteGhost);
		window.draw(pinkGhostSprite.spriteGhost);
		window.draw(redGhostSprite.spriteGhost);

		// Draw our message
		window.draw(messageText);
		window.draw(loseText);
		window.draw(winText);
		//draw the vectors
		for (int i = 0;i < coins.size();++i)
		{
			window.draw(coins[i]);
		}
		for (int i = 0;i < power.size();++i)
		{
			window.draw(power[i]);
		}
		for (int i = 0;i < walls.size();++i)
		{
			window.draw(walls[i]);
		}
		for (int i = 0;i < obstacles.size();++i)
		{
			window.draw(obstacles[i]);
		}
		window.display();
	}
	return 0;
}
