1. Lose.mp4 is a "Lose!" game, Win1.mp4 and Win2.mp4 are the "Win!" game. Win1.mp4 is eating all the ghosts(piazza says that it is also a way to win the game), 
Win2.mp4 is eating all the coins.

2. Tunnel.mp4 shows the pacman can go through the tunnel. And i see that piazza says that everyone should not enter the center, so i follow it, 
and you can judge it by ghosts' first movement. I only shows the pacman going through the tunnel because I see the piazza, and the instructor says 
that the ghost is difficult to go to the tunnel and we can just use the pacman goes through the tunnel. And since the pdf says all the ghosts are 
the same position at the beginning of the game, i follow it even the traditional pacman game is not.

2. I use the font that the professor had used in the Chapter 5. At the start the game, the text shows "PRESS ENTER TO START", and 
just enter the enter key. When you win, the text shows "Win!". When you lose, the text shows "Lose!". If you press the escape, the game window is closed. 

3. I resize all the ghosts and the pacman. And I use the absolute path to use these pictures and the text fonts. 

4. As the video shows, when pacman eats a powerup, I set a slower speed for each ghost in 5 seconds just like the traditional pacman game, 
so pacman can eat the ghost more easily. 

5. Different ghosts may overlap each other. 

6. Keyboard.mp4 is to show the the keyboard control. 