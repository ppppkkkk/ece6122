/*
write the function of the pacman class
*/

#include "pacman.h"

//constructor of the pacman
Pacman::Pacman(string name, float x, float y)
{
	//load
	textureOfPacman.loadFromFile("B:\\pacmango\\pacmango\\graphics\\" + name + ".bmp");
	pacmanSprite.setTexture(textureOfPacman);
	//set position and speed
	pacmanPositionX = x;
	pacmanPositionY = y;
	pacmanSprite.setPosition(pacmanPositionX, pacmanPositionY);
	pacmanSpeed = 0.15f;

}
//constructor of the test pacman
Pacman::Pacman(string name)
{
	textureOfPacman.loadFromFile("B:\\pacmango\\pacmango\\graphics\\" + name + ".bmp");
	pacmanSprite.setTexture(textureOfPacman);
}

//set position
void Pacman::setPosition(float x, float y)
{
	pacmanPositionX = x;
	pacmanPositionY = y;
	pacmanSprite.setPosition(pacmanPositionX, pacmanPositionY);

}

//get boundry
FloatRect Pacman::getPacmanBound()
{
	return pacmanSprite.getGlobalBounds();
}

