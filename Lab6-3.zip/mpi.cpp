/*
Author: PEI XIANGJUN
Class : ECE6122
Last Date Modified : 2022.11.15

For this lab you will be writing a MPI program to determine the steady state heat distribution in
a thin metal plate using synchronous iteration.

A perfectly insulted thin plate with the sides held at 20 ��C and a short segment on one side is
held at 100 ��C is shown below:
You need to write a C\C++ program using CUDA to solve the steady state temperature
distribution in the thin plate shown above. Your program needs to take the following command
line arguments:
1. -n 255 - the number of interior points.
2. -I 10000 �C the number of iterations
Both command line arguments need to be defined and make sure your code check for invalid
command line arguments
Uses type double for your arrays.
Your code needs to output to the console the number of milliseconds it took to calculate the
solution using CUDA events.

Example:
Thin plate calculation took 123.456 milliseconds.

Your code needs to write out to a text file the final temperature values using a comma to
separate the values in the file ��finalTemperatures.csv��. Each row of temperature values should
be on a separate line.

*/
#include <mpi.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#define MASTER 0        /* task ID of master task */
using namespace std;
int main(int argc, char* argv[])
{
	//tasks and task ID 
	int taskid, numtasks;

	//dim of the matrix Width+2
	//int Width = 8;
	int Width;
	// define the num of iterations 
	//int I = 10000;
	int I;
	//get flag
	string argv1 = argv[1];
	string argv3 = argv[3];
	//if valid input
	if (argc != 5 || (!((argv3 == "-n" && argv1 == "-I") || (argv1 == "-n" && argv3 == "-I"))))
	{
		cout << "invalid input!" << endl;
		return 0;
	}

	//get Width and I
	if (argv1 == "-n" && argv3 == "-I")
	{
		Width = atoi(argv[2]);
		I = atoi(argv[4]);
		//	cout<<Width<<I<<endl;
	}
	else if (argv1 == "-I" && argv3 == "-n")
	{
		Width = atoi(argv[4]);
		I = atoi(argv[2]);
		//	cout<<Width<<I<<endl;
	}
	//Width and I must larger than 0
	if (Width <= 0 || I <= 0)
	{
		cout << "invalid input!" << endl;
		return 0;
	}

	//test the time
	double start, end;


	// communicate previous and next Task
	int preTask, nextTask;

	MPI_Status  status;

	MPI_Init(&argc, &argv);

	/* Obtain number of tasks and task ID */
	MPI_Comm_rank(MPI_COMM_WORLD, &taskid);
	MPI_Comm_size(MPI_COMM_WORLD, &numtasks);

	//divide them by array
	int lineSize = Width / numtasks;
	int tempLength = Width;
	if (Width % numtasks != 0)
	{
		lineSize++;
		tempLength = lineSize * numtasks;
	}
	




	//size of every task 
	int cellSize = (lineSize + 2) * (Width + 2) * sizeof(double);
	//sum of the cell
	int num = (tempLength + 2) * (Width + 2);
	//size of the matrix 0-Width+1->Width+2
	int matrixSize = num * sizeof(double);
	//real matrixSize
	int num1 = (Width + 2) *(Width + 2) * sizeof(double);
	double* h = (double*)malloc(cellSize);
	double* g = (double*)malloc(cellSize);
	// collect all the data 
	double* collectData = (double*)malloc(matrixSize);
	//count the cell
	int count = 0;
	int loc = 0;
	//initialze the collectData matrix
	while (count < num)
	{
		//can be divided evenly
		if (count < num1)
		{
			//calculate the location
			int i = count / (Width + 2);
			int j = count - i * (Width + 2);
			loc = count;
			//set the boundry
			if (i == 0)
			{
				collectData[loc] = 20;
				if (j >= (Width + 1) * 0.3 && j < (Width + 1) * 0.7)
				{
					collectData[loc] = 100;
				}
			}
			else if (j == 0 || i == (Width + 1) || j == (Width + 1))
			{
				collectData[loc] = 20;
			}
			else
			{
				collectData[loc] = 0;
			}
			count++;
		}
		//can not
		else
		{
			loc++;
			collectData[loc] = -1;
			count++;
		}
	}
	//when divided evenly
	if (Width % numtasks == 0)
	{
		for (int i = 0; i < lineSize + 2; ++i)
		{
			for (int j = 0; j < Width + 2; ++j)
			{
					if (j == 0 || j == (Width + 1))
					{
						h[i * (Width + 2) + j] = 20;
						g[i * (Width + 2) + j] = 20;
					}
					else
					{
						h[i * (Width + 2) + j] = 0;
						g[i * (Width + 2) + j] = 0;
					}
			}
		}
		//last tasks
		if (taskid == numtasks - 1)
		{
			for (int i = 0; i < Width + 2; ++i)
			{
				h[(lineSize + 1) * (Width + 2) + i] = 20;
				g[(lineSize + 1) * (Width + 2) + i] = 20;
			}
		}
	}
	//can not devided evenlys
	else
	{
		//initialze the block
		for (int i = 0; i < lineSize + 2; ++i)
		{
			for (int j = 0; j < Width + 2; ++j)
			{
				if (taskid * lineSize + 1 + i - 1 < Width + 1)
				{
					if (j == 0 || j == (Width + 1))
					{
						h[i * (Width + 2) + j] = 20;
						g[i * (Width + 2) + j] = 20;
					}
					else
					{
						h[i * (Width + 2) + j] = 0;
						g[i * (Width + 2) + j] = 0;
					}
				}
				else if (taskid * lineSize + 1 + i - 1 == Width + 1)
				{
					h[i * (Width + 2) + j] = 20;
					g[i * (Width + 2) + j] = 20;
				}
				else
				{
					h[i * (Width + 2) + j] = -1;
					g[i * (Width + 2) + j] = -1;
				}

			}
		}
	}

	//the first line
	if (taskid == MASTER)
	{
		for (int i = 0; i < Width + 2; ++i)
		{
			if (i >= 0.3 * (Width + 1) && i < 0.7 * (Width + 1))
			{
				h[i] = 100;
				g[i] = 100;
			}
			else
			{
				h[i] = 20;
				g[i] = 20;
			}
		}
	}


	//communicate with the previous task
	preTask = taskid - 1;
	if (preTask < 0)
	{
		preTask = MPI_PROC_NULL;
	}

	//communicate with the next task
	nextTask = taskid + 1;
	if (nextTask > numtasks - 1)
	{
		nextTask = MPI_PROC_NULL;
	}

	//test time
	start = MPI_Wtime();

	for (int iter = 0; iter < I; ++iter)
	{
		//send and receive the message from&to the previous and next task
		MPI_Sendrecv(&h[Width + 2], Width + 2, MPI_DOUBLE, preTask, 0, &h[(lineSize + 1) * (Width + 2)], Width + 2, MPI_DOUBLE, nextTask, 0, MPI_COMM_WORLD, &status);
		MPI_Sendrecv(&h[lineSize * (Width + 2)], Width + 2, MPI_DOUBLE, nextTask, 0, &h[0], Width + 2, MPI_DOUBLE, preTask, 0, MPI_COMM_WORLD, &status);

		for (int i = 0; i < lineSize + 2; i++)
		{
			for (int j = 0; j < Width + 2; j++)
			{
				if (i != 0 && i != (lineSize + 1) && j != 0 && j != (Width + 1) && h[i * (Width + 2) + j + 1] != -1 && h[i * (Width + 2) + j - 1] != -1 && h[(i + 1) * (Width + 2) + j] != -1 && h[(i - 1) * (Width + 2) + j] != -1)
				{
						g[i * (Width + 2) + j] = 0.25 * (h[i * (Width + 2) + j + 1] + h[i * (Width + 2) + j - 1] + h[(i + 1) * (Width + 2) + j] + h[(i - 1) * (Width + 2) + j]);	
				}
			}
		}

		for (int i = 0; i < lineSize + 2; ++i)
		{
			for (int j = 0; j < Width + 2; ++j)
			{
				h[i * (Width + 2) + j] = g[i * (Width + 2) + j];
			}
		}

	}


	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Gather(&h[Width + 2], lineSize * (Width + 2), MPI_DOUBLE, &collectData[Width + 2], lineSize * (Width + 2), MPI_DOUBLE, 0, MPI_COMM_WORLD);



	//gather all the block


	if (taskid == MASTER)
	{
		// print the time
		end = MPI_Wtime();
		printf("Thin plate calculation took %.3lf milliseconds.\n", (end - start) * 1000);

		//write the data to the .csv
		FILE* fp = fopen("finalTemperatures.csv", "w");
		//if open fail
		if (fp == NULL)
		{
			printf("failed.\n");
			exit(EXIT_FAILURE);
		}
		for (int i = 0; i < (Width + 2) * (Width + 2); i++)
		{
			if (i != (Width + 2) * (Width + 2) - 1)
			{
				fprintf(fp, "%.15lf,", collectData[i]);
			}
			else
			{
				fprintf(fp, "%.15lf", collectData[i]);
			}

			if ((i + 1) % (Width + 2) == 0)
			{
				fprintf(fp, "\n");
			}
		}
		fclose(fp);
	}
	//free the array
	free(collectData);
	free(h);
	free(g);

	MPI_Finalize();
	return 0;
}
