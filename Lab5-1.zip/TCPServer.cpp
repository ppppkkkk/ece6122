/*
Author: PEI XIANGJUN
Class : ECE6122
Last Date Modified : 2022.11.15

TCP Sockets: Debug Logging Server
In real world applications debug/status messages from applications are often sent to a central
logging server so that any issues that may occur can be investigated as to the cause. In this
assignment you will be creating a TCP debug logging server.
Server-70 points
Write a console program that takes as a single command line argument the port number on
which the TCP Server will listen for connection requests. Your server application needs to be
able to maintain the connections from any number of clients. The clients will be sending text
string messages that the server will save in a file called server.log in the same directory as the
server application. The server will add a newline character to the end of each message when
saving to the text file. The messages will be logged as follows:
date & time :: ip_address of client :: message string
Sun Nov 6 20:07:41 2022 :: 192.168.1.1 :: DANGER Will Robinson!!
All messages shall be appended to the server.log file if it already exists, otherwise a new file will
be created. The server logs when clients connect and disconnect using the following format:
Sun Nov 6 20:07:41 2022 :: 192.168.1.1 :: Connected
Sun Nov 6 20:07:41 2022 ::192.168.1.1 :: Disconnected
Example how to output time format
(https://www.tutorialspoint.com/cplusplus/cpp_date_time.htm)
Client-30 points
You need to write a client console program that takes as a command line argument the IP
Address and port number of the server as shown below:
./a.out localhost 61717
The program should continuously prompt the user for messages to send to the server. The
client disconnects and terminates when the user enters the message: quit
Here is example prompting the user for messages
Please enter a message: your string message1
Please enter a message: your string message2
Please enter a message: your string message3
*/
#include <ctime>
#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <SFML/Network.hpp>
#include <fstream>

using namespace std;
using namespace sf;
//listen the connection
TcpListener listener;
//test
vector<TcpSocket*> connectList;
//write log
ofstream ofs;

// if all digital
bool isDigit(string s)
{
    for (int i = 0; s[i] != 0; ++i)
    {
        if (isdigit(s[i]))
        {

        }
        else
        {
            return false;
        }
    }
    return true;
}

//get time
string getTime()
{
    time_t now = time(0);
    char* dt = ctime(&now);
    string stime = dt;
    //remove the enter 
    int pos = stime.find('\n');
    stime = stime.erase(pos);
    return stime;
}
//connect the client
void serverFunc()
{
    while (1)
    {
        //test if has a connection
        TcpSocket* temp = new TcpSocket();
        if (listener.accept(*temp) != Socket::Done)
        {
            delete temp;
            break;
        }
        else
        {
            //if has a connection, set non-blocking mode and push into vector
            temp->setBlocking(false);
            connectList.push_back(temp);
            string stime = getTime();
            cout << stime << " :: " << temp->getRemoteAddress()<<":" << temp->getRemotePort() << " :: " << "Connected" << endl;
            ofs << stime << " :: " << temp->getRemoteAddress() << ":" << temp->getRemotePort() << " :: " << "Connected" << endl;
        }
    }
}

//receive the data
void recvInfo()
{
    while (1)
    {
        for (int i = 0; i < connectList.size(); ++i)
        {
            Packet packet;
            //detect disconnect
            if (connectList[i]->receive(packet) == Socket::Disconnected)
            {
                //get time
                string stime = getTime();
                cout << stime <<" :: " << connectList[i]->getRemoteAddress() << ":" << connectList[i]->getRemotePort() << " :: " << "Disconnected" <<endl;
                ofs  << stime << " :: " << connectList[i]->getRemoteAddress() << ":" << connectList[i]->getRemotePort() << " :: " << "Disconnected" << endl;
                connectList[i]->disconnect();
                connectList.erase(connectList.begin()+i);
                break;
            }
            //if packet has data, receive it
            if (packet.getDataSize() > 0)
            {
                string recvPackInfo;
                packet >> recvPackInfo;
                string stime = getTime();
                cout << stime << " :: " << connectList[i]->getRemoteAddress() << ":" << connectList[i]->getRemotePort() << " :: " << recvPackInfo << endl;
                ofs << stime << " :: " << connectList[i]->getRemoteAddress() << ":" << connectList[i]->getRemotePort() << " :: " << recvPackInfo << endl;
            }
        }
    }
}



int main(int argc, char* argv[])
{
    //judge the argument
    if (argc != 3)
    {
        cout << "Invalid command line argument detected: <invalid argument> "
             << "Please check your values and press any key to end the program!" << endl;
        return 0;
    }
    string argv2 = argv[2];
    if (!isDigit(argv2))
    {
        cout << "Invalid command line argument detected: <invalid argument> "
            << "Please check your values and press any key to end the program!" << endl;
        return 0;
    }
    int port = atoi(argv[2]);
    if (!(port >= 61000 && port <= 65535))
    {
        cout << "Invalid command line argument detected: <invalid argument> "
            << "Please check your values and press any key to end the program!" << endl;
        return 0;
    }
    ofs.open("server.log",ios::app);
    //int port = 61000;
    // Create a server socket to accept new connections
    cout << "The server starts" << endl;
    // Listen to the given port for incoming connections
    if (listener.listen(port) != sf::Socket::Done)
    {
        return 1;
    }
    std::thread connNum(serverFunc);
    recvInfo();
    //detach the thread
    connNum.detach();
    ofs.close();
    return 0;
}
