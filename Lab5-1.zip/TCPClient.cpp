﻿/*
Author: PEI XIANGJUN
Class : ECE6122
Last Date Modified : 2022.11.15

TCP Sockets: Debug Logging Server
In real world applications debug/status messages from applications are often sent to a central
logging server so that any issues that may occur can be investigated as to the cause. In this
assignment you will be creating a TCP debug logging server.
Server-70 points
Write a console program that takes as a single command line argument the port number on
which the TCP Server will listen for connection requests. Your server application needs to be
able to maintain the connections from any number of clients. The clients will be sending text
string messages that the server will save in a file called server.log in the same directory as the
server application. The server will add a newline character to the end of each message when
saving to the text file. The messages will be logged as follows:
date & time :: ip_address of client :: message string
Sun Nov 6 20:07:41 2022 :: 192.168.1.1 :: DANGER Will Robinson!!
All messages shall be appended to the server.log file if it already exists, otherwise a new file will
be created. The server logs when clients connect and disconnect using the following format:
Sun Nov 6 20:07:41 2022 :: 192.168.1.1 :: Connected
Sun Nov 6 20:07:41 2022 ::192.168.1.1 :: Disconnected
Example how to output time format
(https://www.tutorialspoint.com/cplusplus/cpp_date_time.htm)
Client-30 points
You need to write a client console program that takes as a command line argument the IP
Address and port number of the server as shown below:
./a.out localhost 61717
The program should continuously prompt the user for messages to send to the server. The
client disconnects and terminates when the user enters the message: quit
Here is example prompting the user for messages
Please enter a message: your string message1
Please enter a message: your string message2
Please enter a message: your string message3
*/
#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <SFML/Network.hpp>

using namespace std;
using namespace sf;

TcpSocket socket;
//if connects
int flag = 0;

// if all digital
bool isDigit(string s)
{
    for (int i = 0; s[i] != 0; ++i)
    {
        if (isdigit(s[i]))
        {

        }
        else
        {
            return false;
        }
    }
    return true;
}

//receive the control of the server
void recvServer()
{
    while (1)
    {
        Packet packet;
        if (socket.receive(packet) == Socket::Done)
        {
            string recvInfo;
            string address;
            int port;
            packet >> recvInfo >> address >> port;
        }
    }
}

int main(int argc, char* argv[])
{
    //judge the argument
    if (argc != 3)
    {
        cout << "Invalid command line argument detected: <invalid argument> "
            << "Please check your values and press any key to end the program!" << endl;
        system("pause");
        return 0;
    }
    string argv2 = argv[2];
    if (!isDigit(argv2))
    {
        cout << "Invalid command line argument detected: <invalid argument> "
            << "Please check your values and press any key to end the program!" << endl;
        system("pause");
        return 0;
    }
    int port = atoi(argv[2]);
    if (!(port >= 61000 && port <= 65535))
    {
        cout << "Invalid command line argument detected: <invalid argument> "
            << "Please check your values and press any key to end the program!" << endl;
        system("pause");
        return 0;
    }
    string argv1 = argv[1];
    //int port = 61000;
    // Ask for the server address
    //IpAddress server = "localhost";
    IpAddress server = argv1;
    // Connect to the server
    if (socket.connect(server, port) != Socket::Done)
    {
        cout<< "Failed to connect to the server at "<<server <<" on "<<port
            <<". Please check your values and press any key to end program!"<<endl;
        system("pause");
        return 1;
    }
    std::cout << "Connected to server " << server << endl;
    //when connect, flag = 1
    flag = 1;
    std::thread recv(recvServer);
    while (flag)
    {
        cout << "Please enter a message:";
        string input;
        cin >> input;
        //if not input
        if (input.size() < 1)
        {
            continue;
        }
        //if quit, flag = 0 and over
        if (input == "quit")
        {
            socket.disconnect();
            flag = 0;
        }
        else
        {
            //send the packet
            Packet sendToServer;
            sendToServer << input;
            if (socket.send(sendToServer) != Socket::Done)
            {
                return 1;
            }
        }

    }
    //detach the thread
    recv.detach();
    //enter any key to close
    return 0;
}
